import{S as e,i as t,s as n}from"./index.e8d42111.js";class o extends e{constructor(s){super(),t(this,s,null,null,n,{})}}const r=o;export{r as component};
